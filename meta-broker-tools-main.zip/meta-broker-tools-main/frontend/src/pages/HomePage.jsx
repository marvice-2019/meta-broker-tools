import React from "react";
import Hero from "../components/Hero";
import About from "../components/About";
import MarqueeStrip from "../components/MarqueeStrip";
import CRMHighlight from "../components/CRMHighlight";
import WebTech from "../components/WebTech";
import Services from "../components/Services";
import WhyChooseUs from "../components/WhyChooseUs";
import Compliance from "../components/Compliance";
import CTA from "../components/CTA";

export default function HomePage() {
  return (
    <main>
      <Hero />
      <About />
      <MarqueeStrip />
      <div id="funded-form" className="scroll-mt-24" aria-hidden />
      <CRMHighlight />
      <Services />
      <WebTech />
      <WhyChooseUs />
      <Compliance />
      <CTA />
    </main>
  );
}
