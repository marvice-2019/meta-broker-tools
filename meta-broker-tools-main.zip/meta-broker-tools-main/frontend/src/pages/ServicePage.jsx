import React from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import {
  FileText, RefreshCw, ShoppingCart, Smartphone, Apple,
  Headphones, Settings as SettingsIcon, Link as LinkLucide,
  ArrowRight, CheckCircle2,
} from "lucide-react";
import { BRAND, getServiceBySlug } from "../lib/constants";

const ICON_MAP = {
  FileText,
  RefreshCw,
  ShoppingCart,
  Smartphone,
  Apple,
  Headphones,
  Settings: SettingsIcon,
  Link: LinkLucide,
};

export default function ServicePage() {
  const { slug } = useParams();
  const data = slug ? getServiceBySlug(slug) : null;

  if (!data) {
    return <Navigate to="/" replace />;
  }

  const Icon = ICON_MAP[data.icon] || FileText;

  return (
    <main className="bg-black pb-24 pt-8 text-white sm:pb-32 sm:pt-12">
      <div className="pointer-events-none absolute inset-x-0 top-24 h-64 bg-gradient-to-b from-[#FF8A00]/10 to-transparent" />

      <article className="relative mx-auto max-w-7xl px-6">
        <nav className="mb-8 text-xs text-gray-500">
          <Link to="/" className="hover:text-[#2B7FFF]">
            Home
          </Link>
          <span className="mx-2">/</span>
          <Link to="/#services" className="text-gray-400 hover:text-[#2B7FFF]">
            Services
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-300">{data.title}</span>
        </nav>

        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <span className="text-[10px] font-bold uppercase tracking-[0.22em] text-[#FF8A00]">
                Services
              </span>
              <h1 className="mt-3 font-display text-3xl font-black leading-tight tracking-tighter sm:text-5xl md:text-6xl">
                {data.title}
              </h1>
              <p className="mt-4 max-w-2xl text-lg text-gray-300">{data.intro}</p>

              <div className="mt-8 flex items-start gap-4 rounded-2xl border border-[#FF8A00]/25 bg-[#FF8A00]/5 p-5">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-[#FF8A00]/40 bg-[#FF8A00]/15">
                  <Icon className="h-6 w-6 text-[#FF8A00]" />
                </div>
                <p className="text-sm leading-relaxed text-gray-400">{data.desc}</p>
              </div>

              <div className="mt-10 space-y-5 text-base leading-relaxed text-gray-400">
                {data.paragraphs.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>

              <ul className="mt-10 grid gap-3 sm:grid-cols-2">
                {data.highlights.map((h) => (
                  <li
                    key={h}
                    className="flex gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-4 text-sm text-gray-300"
                  >
                    <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#FF8A00]" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>

          <aside className="lg:col-span-4">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.1 }}
              className="sticky top-28 space-y-5"
            >
              <div className="rounded-2xl border border-white/10 bg-[#07070A] p-6">
                <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-gray-500">
                  Next step
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-gray-400">
                  Share your scope and timelines — we&apos;ll map the fastest delivery path and propose milestones.
                </p>
                <Link
                  to="/#contact"
                  className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] py-3.5 text-sm font-semibold text-white"
                >
                  Book a demo <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/#services" className="mt-3 block text-center text-sm text-[#2B7FFF] hover:underline">
                  View all services
                </Link>
              </div>

              <p className="text-center text-xs text-gray-600">
                {BRAND.name} — {BRAND.tagline}
              </p>
            </motion.div>
          </aside>
        </div>
      </article>
    </main>
  );
}

