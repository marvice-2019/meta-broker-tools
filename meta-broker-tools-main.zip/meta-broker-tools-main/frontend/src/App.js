import React from "react";
import { Routes, Route } from "react-router-dom";
import TopBar from "./components/TopBar";
import Header from "./components/Header";
import Footer from "./components/Footer";
import ScrollToTop from "./components/ScrollToTop";
import HomePage from "./pages/HomePage";
import SolutionPage from "./pages/SolutionPage";
import ServicePage from "./pages/ServicePage";

function App() {
  return (
    <div className="min-h-screen bg-black font-body text-white antialiased">
      <ScrollToTop />
      <TopBar />
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/solutions/:slug" element={<SolutionPage />} />
        <Route path="/services/:slug" element={<ServicePage />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
