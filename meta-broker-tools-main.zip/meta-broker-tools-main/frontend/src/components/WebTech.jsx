import React from "react";
import { motion } from "framer-motion";
import { Code2, Cpu, Shield, Globe2, Layers, Zap } from "lucide-react";
import { BRAND } from "../lib/constants";

const PILLARS = [
  {
    icon: Code2,
    title: "Modern frontends",
    text: "React-based trader portals, marketing sites, and dashboards tuned for speed, SEO, and conversion.",
  },
  {
    icon: Cpu,
    title: "APIs & integrations",
    text: "REST and streaming interfaces that connect CRM, bridges, risk, and third-party vendors without fragile glue code.",
  },
  {
    icon: Layers,
    title: "Composable architecture",
    text: "Services you can roll out in phases — start with CRM or web, then add copier, risk, or custom modules as you scale.",
  },
  {
    icon: Shield,
    title: "Security by default",
    text: "Auth hardening, audit trails, and deployment patterns aligned with how regulated desks expect software to behave.",
  },
  {
    icon: Globe2,
    title: "Multi-region ready",
    text: "Hosting and failover patterns for teams that care about latency across Asia, MENA, EU, and the Americas.",
  },
  {
    icon: Zap,
    title: "Performance budgets",
    text: "We treat Core Web Vitals and API latency as product features — not afterthoughts once traffic spikes.",
  },
];

export default function WebTech() {
  return (
    <section
      id="web-tech"
      data-testid="web-tech-section"
      className="relative overflow-hidden border-y border-white/10 bg-[#05050A] py-24 text-white sm:py-28"
    >
      <div className="pointer-events-none absolute left-1/2 top-0 h-px w-[min(100%,720px)] -translate-x-1/2 bg-gradient-to-r from-transparent via-[#FF8A00] to-transparent" />

      <div className="relative mx-auto max-w-7xl px-6">
        <div className="mb-14 grid grid-cols-12 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65 }}
            className="col-span-12 md:col-span-4"
          >
            <div className="font-display text-[100px] font-black leading-[0.85] text-gradient-brand opacity-90 select-none sm:text-[130px]">
              03
            </div>
            <div className="mt-2 text-xs font-bold uppercase tracking-[0.3em] text-[#FF8A00]">Web-Tech</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, delay: 0.08 }}
            className="col-span-12 md:col-span-8 md:pt-6"
          >
            <h2 className="font-display text-3xl font-black leading-tight tracking-tighter md:text-5xl">
              Engineering that matches
              <br />
              <span className="text-gradient-brand">your broker roadmap.</span>
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-gray-400">
              {BRAND.name} ships the same stack we use on our own delivery: typed APIs, observable releases, and UI
              systems that stay coherent from marketing site to trader&apos;s room. Explore{" "}
              <a href="/#services" className="text-[#2B7FFF] underline-offset-4 hover:underline">
                Services
              </a>{" "}
              for project lanes, or jump to{" "}
              <a href="/#contact" className="text-[#FF8A00] underline-offset-4 hover:underline">
                Contact
              </a>{" "}
              when you are ready to scope a build.
            </p>
          </motion.div>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PILLARS.map((p, i) => {
            const Icon = p.icon;
            const accent = i % 2 === 0 ? "blue" : "orange";
            return (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.45, delay: i * 0.05 }}
                className="rounded-2xl border border-white/10 bg-black/40 p-6 transition-colors hover:border-white/20"
              >
                <div
                  className={`mb-4 flex h-11 w-11 items-center justify-center rounded-xl border ${
                    accent === "blue"
                      ? "border-[#2B7FFF]/35 bg-[#2B7FFF]/10 text-[#2B7FFF]"
                      : "border-[#FF8A00]/35 bg-[#FF8A00]/10 text-[#FF8A00]"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="font-display text-lg font-semibold text-white">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-gray-400">{p.text}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
