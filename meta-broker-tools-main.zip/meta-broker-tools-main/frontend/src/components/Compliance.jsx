import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck, ArrowRight, CheckCircle2 } from "lucide-react";
import { KYC_IMAGE, COMPLIANCE_POINTS } from "../lib/constants";

export default function Compliance() {
  return (
    <section
      id="compliance"
      data-testid="compliance-section"
      className="relative bg-black py-20 sm:py-24"
    >
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative rounded-3xl border border-[#FF8A00]/30 bg-gradient-to-bl from-[#0A0500] via-black to-[#050510] p-8 sm:p-12 overflow-hidden"
        >
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-[#FF8A00] rounded-full blur-[200px] opacity-15" />
          <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-[#2B7FFF] rounded-full blur-[200px] opacity-15" />

          <div className="grid md:grid-cols-2 gap-10 items-center relative">
            {/* Image */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src={KYC_IMAGE}
                  alt="KYC / AML Compliance"
                  className="w-full h-auto object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
            </motion.div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h3 className="font-display text-2xl sm:text-4xl font-black text-gradient-brand flex items-center gap-3 leading-tight">
                <ShieldCheck className="w-8 h-8 text-[#FF8A00] shrink-0" />
                KYC / AML Compliance
              </h3>

              <p className="text-gray-400 mt-5 leading-relaxed">
                Meta Broker Tool is built on strict global KYC and AML standards. Our platform
                protects users, shields operators, and ensures every deployment stays inside
                legal and ethical boundaries.
              </p>

              <div className="mt-7 space-y-4">
                {COMPLIANCE_POINTS.map((p, i) => (
                  <motion.div
                    key={p.title}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    data-testid={`compliance-point-${i}`}
                    className="flex items-start gap-3"
                  >
                    <CheckCircle2 className="w-5 h-5 text-[#FF8A00] shrink-0 mt-0.5" />
                    <div>
                      <div className="text-white font-semibold text-sm">{p.title}</div>
                      <div className="text-gray-400 text-sm mt-0.5">{p.desc}</div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <a
                href="/#contact"
                data-testid="compliance-cta"
                className="inline-flex items-center gap-2 mt-8 bg-gradient-to-r from-[#FF8A00] to-[#2B7FFF] text-white px-7 py-3 rounded-full font-semibold btn-glow-orange"
              >
                Learn About Compliance
                <ArrowRight className="w-4 h-4" />
              </a>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
