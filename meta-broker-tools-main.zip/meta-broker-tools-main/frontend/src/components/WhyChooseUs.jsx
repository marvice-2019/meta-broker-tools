import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus } from "lucide-react";
import { WHY_CHOOSE_FAQ } from "../lib/constants";

export default function WhyChooseUs() {
  const [open, setOpen] = useState(0);

  return (
    <section
      id="why"
      data-testid="why-section"
      className="relative bg-black text-white py-24 sm:py-32"
    >
      <div className="max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <span className="inline-block bg-[#FF8A00]/15 border border-[#FF8A00]/30 text-[#FF8A00] px-4 py-1.5 rounded-full text-[11px] font-bold tracking-[0.22em] uppercase mb-5">
            Why Meta Broker Tool
          </span>
          <h2 className="font-display text-3xl md:text-5xl font-black leading-tight tracking-tighter">
            Why brokers choose us, <span className="text-gradient-brand">in detail</span>
          </h2>
        </motion.div>

        <div className="space-y-3">
          {WHY_CHOOSE_FAQ.map((item, i) => {
            const isOpen = open === i;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className={`border rounded-xl overflow-hidden transition-colors ${
                  isOpen ? "border-[#2B7FFF]/60 bg-[#05101F]" : "border-white/10 bg-[#0A0A0C]"
                }`}
              >
                <button
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  data-testid={`faq-toggle-${i}`}
                  aria-expanded={isOpen}
                  className="w-full flex justify-between items-center gap-6 px-6 py-5 text-left"
                >
                  <span className="font-display text-base md:text-lg font-medium">{item.q}</span>
                  <span
                    className={`w-9 h-9 shrink-0 rounded-full border flex items-center justify-center transition-colors ${
                      isOpen
                        ? "border-[#FF8A00] bg-[#FF8A00]/10 text-[#FF8A00]"
                        : "border-white/20 text-white/70"
                    }`}
                  >
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="px-6 pb-5 text-gray-400 text-sm leading-relaxed">
                        {item.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
