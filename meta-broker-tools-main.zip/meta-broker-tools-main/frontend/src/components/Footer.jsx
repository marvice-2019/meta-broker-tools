import React, { useState } from "react";
import { Mail, Phone, Twitter, Facebook, Instagram, Linkedin, Send, CheckCircle2 } from "lucide-react";
import { toast, Toaster } from "sonner";
import { BRAND } from "../lib/constants";

const QUICK_LINKS = [
  { label: "Home", href: "/#home" },
  { label: "About Us", href: "/#about" },
  { label: "Services", href: "/#services" },
  { label: "Web-Tech", href: "/#web-tech" },
  { label: "Why Choose Us", href: "/#why" },
  { label: "Contact", href: "/#contact" },
];

export default function Footer() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      toast.error("Please enter a valid email address");
      return;
    }
    setDone(true);
    toast.success("Subscribed! Watch your inbox for updates.");
    setEmail("");
    setTimeout(() => setDone(false), 3500);
  };

  return (
    <footer
      data-testid="site-footer"
      className="relative bg-[#05050A] border-t border-white/10 text-gray-300 pt-20 pb-8 overflow-hidden"
    >
      <Toaster theme="dark" position="top-right" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[2px] bg-gradient-to-r from-transparent via-[#2B7FFF] to-transparent opacity-60" />

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-10">
        {/* Brand */}
        <div className="space-y-5">
          <img src={BRAND.logo} alt={BRAND.name} className="h-25 w-auto object-contain" />
          <p className="text-gray-400 text-sm leading-relaxed max-w-xs">
            {BRAND.name} delivers the full broker technology stack — engineered to help forex
            brokers, prop firms, and fintech teams ship faster and scale without drag.
          </p>
          <div className="flex gap-3">
            {[
              { Icon: Twitter, href: BRAND.socials.twitter, label: "Twitter" },
              { Icon: Facebook, href: BRAND.socials.facebook, label: "Facebook" },
              { Icon: Instagram, href: BRAND.socials.instagram, label: "Instagram" },
              { Icon: Linkedin, href: BRAND.socials.linkedin, label: "LinkedIn" },
            ].map(({ Icon, href, label }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                data-testid={`footer-${label.toLowerCase()}`}
                className="w-9 h-9 flex items-center justify-center rounded-full border border-white/10 text-gray-400 hover:text-white hover:border-[#2B7FFF] hover:bg-[#2B7FFF]/10 transition-all"
              >
                <Icon className="w-4 h-4" />
              </a>
            ))}
          </div>
        </div>

        {/* Quick links */}
        <div>
          <h3 className="font-display text-white text-lg font-semibold mb-5">Quick Links</h3>
          <ul className="space-y-3">
            {QUICK_LINKS.map((l) => (
              <li key={l.label}>
                <a
                  href={l.href}
                  data-testid={`footer-link-${l.label.toLowerCase().replace(/\s/g, "-")}`}
                  className="text-sm text-gray-400 hover:text-[#2B7FFF] transition-colors inline-flex items-center gap-2 group"
                >
                  <span className="w-1 h-1 rounded-full bg-[#FF8A00] group-hover:w-4 transition-all" />
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h3 className="font-display text-white text-lg font-semibold mb-5">Contact Us</h3>
          <ul className="space-y-4 text-sm text-gray-400">
            <li className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-[#2B7FFF] shrink-0" />
              <a href={`mailto:${BRAND.email}`} className="hover:text-[#2B7FFF] transition-colors">
                {BRAND.email}
              </a>
            </li>
            <li className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-[#FF8A00] shrink-0" />
              <a href={`tel:${BRAND.phone.replace(/\s/g, "")}`} className="hover:text-[#FF8A00] transition-colors">
                {BRAND.phone}
              </a>
            </li>
          </ul>
        </div>

        {/* Newsletter */}
        <div>
          <h3 className="font-display text-white text-lg font-semibold mb-5">Stay Updated</h3>
          <p className="text-sm text-gray-400 mb-4">
            Monthly briefs on broker tech, regulation shifts, and product drops. No spam.
          </p>
          <form onSubmit={handleSubmit} className="flex flex-col gap-3" data-testid="newsletter-form">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@broker.com"
              data-testid="newsletter-email-input"
              className="w-full px-4 py-3 rounded-full bg-black border border-white/10 focus:outline-none focus:border-[#2B7FFF] text-white text-sm placeholder-gray-500 transition-colors"
              required
            />
            <button
              type="submit"
              data-testid="newsletter-submit"
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] hover:opacity-95 text-white px-5 py-3 rounded-full font-semibold text-sm btn-glow-blue"
            >
              {done ? (
                <>
                  <CheckCircle2 className="w-4 h-4" /> Subscribed
                </>
              ) : (
                <>
                  Subscribe <Send className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-white/10 mt-14 pt-6 text-center text-gray-500 text-xs">
        &copy; {new Date().getFullYear()} {BRAND.name}. All rights reserved. Technology vendor — not a broker.
      </div>
    </footer>
  );
}
