import React from "react";
import { motion } from "framer-motion";
import { Rocket, Lightbulb, Users, Timer, ShieldCheck, ArrowRight } from "lucide-react";
import { BRAND, CTA_POINTS, HERO_IMAGES } from "../lib/constants";

const ICON_MAP = { Lightbulb, Users, Timer, ShieldCheck };

export default function CTA() {
  return (
    <section
      id="contact"
      data-testid="cta-section"
      className="relative py-24 overflow-hidden"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url('${HERO_IMAGES[0]}')` }}
      />
      <div className="absolute inset-0 bg-black/85" />
      <div className="absolute -left-40 top-1/3 w-[500px] h-[500px] bg-[#2B7FFF] rounded-full blur-[200px] opacity-15" />
      <div className="absolute -right-40 bottom-0 w-[500px] h-[500px] bg-[#FF8A00] rounded-full blur-[200px] opacity-15" />

      <div className="relative max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="glass-panel rounded-3xl p-10 sm:p-14"
        >
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left */}
            <div>
              <span className="inline-block bg-[#2B7FFF]/15 border border-[#2B7FFF]/30 text-[#2B7FFF] px-4 py-1.5 rounded-full text-[11px] font-bold tracking-[0.22em] uppercase mb-5">
                Get Started
              </span>

              <h2 className="font-display text-3xl sm:text-5xl font-black leading-tight tracking-tighter">
                Ready to <span className="text-gradient-brand">upgrade</span> your broker stack?
              </h2>

              <p className="text-gray-400 mt-5 text-base leading-relaxed max-w-md">
                Book a 30-minute discovery call. We'll audit your current setup, map out what's
                slowing you down, and show you exactly how Meta Broker Tool plugs in.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 mt-8">
                <a
                  href={`mailto:${BRAND.email}`}
                  data-testid="cta-book-demo"
                  className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] text-white px-7 py-3.5 rounded-full font-semibold btn-glow-blue"
                >
                  <Rocket className="w-4 h-4" />
                  Book a Demo
                </a>
                <a
                  href="/#services"
                  data-testid="cta-explore"
                  className="inline-flex items-center justify-center gap-2 border border-white/20 hover:border-[#FF8A00] text-white px-7 py-3.5 rounded-full font-semibold transition-colors hover:text-[#FF8A00]"
                >
                  View Services
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Right: points */}
            <div className="grid gap-4">
              {CTA_POINTS.map((p, i) => {
                const Icon = ICON_MAP[p.icon] || Lightbulb;
                return (
                  <motion.div
                    key={p.text}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.08 }}
                    data-testid={`cta-point-${i}`}
                    className="flex items-center gap-4 bg-black/40 border border-white/10 rounded-xl p-4 hover:border-[#2B7FFF]/50 transition-colors"
                  >
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                        i % 2 === 0
                          ? "bg-[#2B7FFF]/15 border border-[#2B7FFF]/40 text-[#2B7FFF]"
                          : "bg-[#FF8A00]/15 border border-[#FF8A00]/40 text-[#FF8A00]"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <p className="text-gray-200 font-medium">{p.text}</p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
