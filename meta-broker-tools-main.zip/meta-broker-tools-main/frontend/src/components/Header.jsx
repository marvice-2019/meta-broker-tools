import React, { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu, X, Home, Info, Cpu, Wrench, Code2, Phone, ChevronDown,
  Sparkles, Layout, Waves, Lock, Repeat2, Database, Globe, Server,
  ShieldAlert, Rocket, Star, Landmark, ArrowRight, ClipboardList,
  Megaphone, FileSpreadsheet, Users,
  FileText, RefreshCw, ShoppingCart, Smartphone, Apple, Headphones,
  Settings as SettingsIcon, Link as LinkLucide,
} from "lucide-react";
import { BRAND, NAV_ITEMS, FX_DROPDOWN, FUNDED_FORM_DROPDOWN, SERVICES_DROPDOWN } from "../lib/constants";

const ICON_MAP = {
  Home, Info, Cpu, Wrench, Code2, Phone,
  Sparkles, Layout, Waves, Lock, Repeat2, Database, Globe, Server,
  ShieldAlert, Rocket, UserStar: Star, Landmark,
  ClipboardList, Megaphone, FileSpreadsheet, Users,
  FileText, RefreshCw, ShoppingCart, Smartphone, Apple, Headphones,
  Settings: SettingsIcon,
  Link: LinkLucide,
};

function navDropdownCols(dropdownId) {
  if (dropdownId === "funded") return FUNDED_FORM_DROPDOWN;
  if (dropdownId === "services") return SERVICES_DROPDOWN;
  return FX_DROPDOWN;
}

/** Matches Tailwind column classes to dropdown shape — avoids an empty third column when only two groups exist. */
function megaMenuGridClass(columnCount) {
  const base =
    "grid grid-cols-1 divide-y divide-white/5 p-2 lg:divide-y-0 lg:divide-white/10";
  if (columnCount >= 3) return `${base} lg:grid-cols-2 lg:divide-x xl:grid-cols-3`;
  if (columnCount === 2) return `${base} lg:grid-cols-2 lg:divide-x`;
  return `${base}`;
}

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [fxOpen, setFxOpen] = useState(null); // index of open dropdown
  const [mobileFxOpen, setMobileFxOpen] = useState(null); // index of open mobile dropdown

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  useEffect(() => {
    if (fxOpen === null) return;
    const onKey = (e) => {
      if (e.key === "Escape") setFxOpen(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [fxOpen]);

  useEffect(() => {
    const clearFxIfNarrow = () => {
      if (typeof window !== "undefined" && window.matchMedia("(max-width: 1023px)").matches) {
        setFxOpen(null);
      }
    };
    clearFxIfNarrow();
    window.addEventListener("resize", clearFxIfNarrow);
    return () => window.removeEventListener("resize", clearFxIfNarrow);
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 1024px)");
    const onChange = () => {
      if (mq.matches) setMobileOpen(false);
    };
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  return (
    <header
      data-testid="site-header"
      className={`sticky top-0 z-50 isolate overflow-visible border-b transition-all duration-500 ${
        scrolled
          ? "border-white/10 bg-black/95 backdrop-blur-xl lg:bg-black/85"
          : "border-white/5 bg-black backdrop-blur-md lg:bg-black/40 lg:backdrop-blur-md"
      }`}
    >
      <div
        className="relative mx-auto max-w-7xl px-4 sm:px-6"
        onMouseLeave={() => setFxOpen(null)}
      >
        <div className="flex h-16 items-center justify-between gap-3 overflow-visible sm:h-20">
          {/* Logo: no flex-1 on small screens — avoids a full-width hit area fighting the menu button */}
          <Link
            to="/"
            data-testid="logo-link"
            className="group flex min-w-0 shrink-0 items-center py-1 lg:py-0"
            onClick={() => setMobileOpen(false)}
          >
            <img
              src={BRAND.logo}
              alt={BRAND.name}
              decoding="async"
              className="h-11 w-auto max-h-11 object-contain object-left sm:h-12 sm:max-h-12 lg:h-14 lg:max-h-14"
              style={{ maxWidth: "min(280px, calc(100vw - 5.25rem))" }}
            />
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden min-w-0 flex-1 items-center justify-center gap-2 lg:flex">
            {NAV_ITEMS.map((item, idx) => {
              const Icon = ICON_MAP[item.icon] || Home;
              if (item.hasDropdown) {
                return (
                  <div key={item.label} onMouseEnter={() => setFxOpen(idx)}>
                    <button
                      type="button"
                      data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                      className="nav-underline flex items-center gap-2 px-5 py-2 text-sm font-medium text-gray-200 transition-colors hover:text-white"
                      aria-expanded={fxOpen === idx}
                      aria-haspopup="true"
                      onClick={() => setFxOpen(fxOpen === idx ? null : idx)}
                    >
                      <Icon className="h-4 w-4 text-[#2B7FFF]" />
                      <span className="font-display tracking-wide">{item.label}</span>
                      <ChevronDown
                        className={`h-3.5 w-3.5 shrink-0 transition-transform ${fxOpen === idx ? "rotate-180" : ""}`}
                      />
                    </button>
                  </div>
                );
              }

              return (
                <a
                  key={item.label}
                  href={item.href}
                  data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                  className="nav-underline flex items-center gap-2 whitespace-nowrap px-4 py-2 text-sm font-medium text-gray-200 transition-colors hover:text-white"
                >
                  <Icon className="h-4 w-4 text-[#2B7FFF]" />
                  <span className="font-display tracking-wide">{item.label}</span>
                </a>
              );
            })}
          </nav>

          {/* Mobile Toggle */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setMobileOpen(true);
            }}
            data-testid="mobile-menu-open"
            className="relative z-[5] flex h-11 w-11 shrink-0 touch-manipulation items-center justify-center rounded-lg text-white hover:bg-white/10 active:bg-white/15 lg:hidden"
            aria-label="Open menu"
            aria-expanded={mobileOpen}
          >
            <Menu className="h-6 w-6" strokeWidth={2} />
          </button>
        </div>

        {/* Desktop mega-menu only at lg+ — never mount on mobile (avoids z-index blocking the drawer) */}
        <div className="hidden lg:contents">
        <AnimatePresence>
          {fxOpen !== null && NAV_ITEMS[fxOpen]?.hasDropdown && (() => {
            const megaCols = navDropdownCols(NAV_ITEMS[fxOpen].dropdownId || "fx");
            return (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              transition={{ duration: 0.22 }}
              data-testid={`nav-dropdown-${NAV_ITEMS[fxOpen].dropdownId || "fx"}`}
              className="absolute left-0 right-0 top-full z-[200] flex justify-center pt-2"
            >
              <div className="w-full max-w-[900px] overflow-hidden rounded-2xl border border-white/10 bg-[#07070A] shadow-2xl shadow-[#2B7FFF]/10">
                <div className={megaMenuGridClass(megaCols.length)}>
                  {megaCols.map((col) => (
                    <div key={col.group} className="p-5 sm:p-6">
                      <div className="mb-4 text-[10px] font-bold uppercase tracking-[0.22em] text-[#FF8A00]">
                        {col.group}
                      </div>
                      <div className="space-y-1">
                        {col.items.map((it) => {
                          const ItIcon = ICON_MAP[it.icon] || Sparkles;
                          const row = (
                            <>
                              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[#2B7FFF]/30 bg-[#2B7FFF]/10 transition group-hover:bg-[#2B7FFF]/20">
                                <ItIcon className="h-4 w-4 text-[#2B7FFF]" />
                              </div>
                              <div className="min-w-0">
                                <div className="font-display text-sm font-semibold text-white">{it.title}</div>
                                <div className="mt-0.5 text-xs leading-relaxed text-gray-400">{it.desc}</div>
                              </div>
                            </>
                          );
                          const testId = `nav-dropdown-item-${it.title.toLowerCase().replace(/\s/g, "-")}`;
                          const className =
                            "group flex items-start gap-3 rounded-xl p-3 transition-all hover:bg-white/5";
                          if (it.href) {
                            return (
                              <Link
                                key={`${it.title}-${it.href}`}
                                to={it.href}
                                onClick={() => setFxOpen(null)}
                                data-testid={testId}
                                className={className}
                              >
                                {row}
                              </Link>
                            );
                          }
                          if (NAV_ITEMS[fxOpen]?.dropdownId === "services") {
                            return (
                              <Link
                                key={it.slug}
                                to={`/services/${it.slug}`}
                                onClick={() => setFxOpen(null)}
                                data-testid={testId}
                                className={className}
                              >
                                {row}
                              </Link>
                            );
                          }
                          return (
                            <Link
                              key={it.slug}
                              to={`/solutions/${it.slug}`}
                              onClick={() => setFxOpen(null)}
                              data-testid={testId}
                              className={className}
                            >
                              {row}
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
            );
          })()}
        </AnimatePresence>
        </div>
      </div>

      {/* Mobile drawer: portal + AnimatePresence inside portal so exit works; body stacking above header */}
      {typeof document !== "undefined" &&
        createPortal(
          <AnimatePresence>
            {mobileOpen && (
              <motion.div
                key="mobile-drawer"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                data-testid="mobile-menu"
                className="fixed inset-0 z-[9999] flex flex-col bg-black lg:hidden"
                role="dialog"
                aria-modal="true"
                aria-label="Navigation menu"
              >
                <div className="flex h-full min-h-0 flex-col px-4 py-6 sm:px-6 pb-[max(1.5rem,env(safe-area-inset-bottom,0px))]">
                  <div className="flex shrink-0 items-center justify-between border-b border-white/10 pb-4">
                    <span className="font-display text-lg font-semibold tracking-tight text-white">{BRAND.name}</span>
                    <button
                      type="button"
                      onClick={() => setMobileOpen(false)}
                      data-testid="mobile-menu-close"
                      className="flex h-11 w-11 shrink-0 touch-manipulation items-center justify-center rounded-lg text-white hover:bg-white/10"
                      aria-label="Close menu"
                    >
                      <X className="h-7 w-7" />
                    </button>
                  </div>

                  <nav className="mt-8 flex-1 min-h-0 space-y-3 overflow-y-auto overscroll-contain">
                    {NAV_ITEMS.map((item, idx) => {
                      const Icon = ICON_MAP[item.icon] || Home;
                      if (item.hasDropdown) {
                        return (
                          <div key={item.label}>
                            <button
                              type="button"
                              onClick={() => setMobileFxOpen(mobileFxOpen === idx ? null : idx)}
                              data-testid={`mobile-nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                              className="flex w-full items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-4 text-left transition hover:border-[#2B7FFF]/50"
                              aria-expanded={mobileFxOpen === idx}
                            >
                              <span className="flex items-center gap-3">
                                <Icon className="h-5 w-5 text-[#2B7FFF]" />
                                <span className="font-display text-base">{item.label}</span>
                              </span>
                              <ChevronDown
                                className={`h-4 w-4 transition-transform ${mobileFxOpen === idx ? "rotate-180" : ""}`}
                              />
                            </button>
                            <AnimatePresence>
                              {mobileFxOpen === idx && (
                                <motion.div
                                  initial={{ opacity: 0, y: -6 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, y: -6 }}
                                  transition={{ duration: 0.2 }}
                                  className="ml-2 mt-2 space-y-1"
                                >
                                  {navDropdownCols(item.dropdownId || "fx").flatMap((col) => col.items).map((it) => {
                                    const ItIcon = ICON_MAP[it.icon] || Sparkles;
                                    const className =
                                      "flex items-center gap-3 rounded-lg px-4 py-3 text-sm text-gray-300 hover:bg-white/5 hover:text-white";
                                    const to = it.href
                                      || (item.dropdownId === "services" ? `/services/${it.slug}` : `/solutions/${it.slug}`);
                                    return (
                                      <Link
                                        key={it.href ? `${it.title}-${it.href}` : it.slug}
                                        to={to}
                                        onClick={() => setMobileOpen(false)}
                                        className={className}
                                      >
                                        <ItIcon className="h-4 w-4 text-[#FF8A00]" />
                                        {it.title}
                                      </Link>
                                    );
                                  })}
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        );
                      }
                      return (
                        <a
                          key={item.label}
                          href={item.href}
                          onClick={() => setMobileOpen(false)}
                          data-testid={`mobile-nav-${item.label.toLowerCase().replace(/\s/g, "-")}`}
                          className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-4 transition hover:border-[#2B7FFF]/50"
                        >
                          <Icon className="h-5 w-5 text-[#2B7FFF]" />
                          <span className="font-display text-base">{item.label}</span>
                        </a>
                      );
                    })}
                  </nav>

                  <a
                    href="/#contact"
                    onClick={() => setMobileOpen(false)}
                    data-testid="mobile-cta"
                    className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] py-4 font-semibold text-white"
                  >
                    Book a Demo <ArrowRight className="h-4 w-4" />
                  </a>
                </div>
              </motion.div>
            )}
          </AnimatePresence>,
          document.body
        )}
    </header>
  );
}
