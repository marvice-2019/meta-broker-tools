import React from "react";
import { motion } from "framer-motion";
import {
  FileText, RefreshCw, ShoppingCart, Smartphone, Apple,
  Headphones, Settings, Link as LinkIcon, ArrowUpRight
} from "lucide-react";
import { Link } from "react-router-dom";
import { SERVICES, serviceSectionHashId, serviceSlug } from "../lib/constants";

const ICON_MAP = {
  FileText, RefreshCw, ShoppingCart, Smartphone, Apple,
  Headphones, Settings, Link: LinkIcon,
};

export default function Services() {
  return (
    <section
      id="services"
      data-testid="services-section"
      className="relative bg-[#05050A] text-white py-24 sm:py-32 overflow-hidden"
    >
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#2B7FFF] to-transparent" />

      <div className="max-w-7xl mx-auto px-6 relative">
        {/* Left-aligned section header */}
        <div className="grid grid-cols-12 gap-6 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="col-span-12 md:col-span-4"
          >
            <div className="font-display text-[120px] sm:text-[160px] font-black leading-[0.8] text-gradient-brand opacity-90 select-none">
              02
            </div>
            <div className="text-xs uppercase tracking-[0.3em] text-[#2B7FFF] font-bold mt-2">
              Our Services
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="col-span-12 md:col-span-8 md:pt-8"
          >
            <h2 className="font-display text-3xl md:text-5xl font-black leading-tight tracking-tighter">
              Web, mobile & CRM —
              <br />
              <span className="text-gradient-brand">broker-grade.</span>
            </h2>
            <p className="text-gray-400 mt-5 text-base leading-relaxed max-w-xl">
              Every service below is shipped by the same team that builds our broker stack — so you
              get the same speed, security, and scalability standards in everything we deliver.
            </p>
          </motion.div>
        </div>

        {/* Numbered list / row layout */}
        <div className="border-t border-white/10">
          {SERVICES.map((s, i) => {
            const Icon = ICON_MAP[s.icon] || FileText;
            const isOrange = i % 3 === 1;
            return (
              <motion.div
                id={serviceSectionHashId(s.title)}
                key={s.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05, duration: 0.5 }}
                data-testid={`service-card-${i}`}
                className="group relative border-b border-white/10 pr-2 transition-all duration-500 hover:bg-gradient-to-r hover:from-[#2B7FFF]/5 hover:to-[#FF8A00]/5"
              >
                <Link
                  to={`/services/${serviceSlug(s.title)}`}
                  className="grid grid-cols-12 gap-4 items-center py-7"
                >
                  <div className="col-span-2 sm:col-span-1 font-display text-sm font-bold text-gray-600 tabular-nums tracking-widest">
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center border transition-all group-hover:scale-110 ${
                        isOrange
                          ? "bg-[#FF8A00]/10 border-[#FF8A00]/30 text-[#FF8A00]"
                          : "bg-[#2B7FFF]/10 border-[#2B7FFF]/30 text-[#2B7FFF]"
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="col-span-8 sm:col-span-5">
                    <h3 className="font-display text-lg sm:text-xl font-semibold group-hover:text-white transition-colors">
                      {s.title}
                    </h3>
                  </div>
                  <div className="hidden sm:block col-span-4 text-sm text-gray-400 leading-relaxed">
                    {s.desc}
                  </div>
                  <div className="hidden sm:flex col-span-1 justify-end">
                    <ArrowUpRight className="w-5 h-5 text-gray-600 group-hover:text-[#FF8A00] group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                  </div>
                </Link>

                {/* Accent underline on hover */}
                <div className="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] w-0 group-hover:w-full transition-all duration-500" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
