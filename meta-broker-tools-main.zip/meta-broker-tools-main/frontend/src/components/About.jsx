import React from "react";
import { motion } from "framer-motion";
import {
  Zap, Repeat, Users, LayoutDashboard, Network, GitFork, ArrowUpRight
} from "lucide-react";
import { ABOUT_IMAGE, ABOUT_FEATURES, BRAND } from "../lib/constants";

const ICON_MAP = { Zap, Repeat, Users, LayoutDashboard, Network, GitFork };

export default function About() {
  return (
    <section
      id="about"
      data-testid="about-section"
      className="relative bg-black text-white py-24 sm:py-32 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 relative">
        {/* Top row: massive number + heading */}
        <div className="grid grid-cols-12 gap-8 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="col-span-12 md:col-span-4"
          >
            <div className="font-display text-[140px] sm:text-[180px] font-black leading-[0.8] text-gradient-brand opacity-90 select-none">
              01
            </div>
            <div className="text-xs uppercase tracking-[0.3em] text-[#FF8A00] font-bold mt-2">
              About {BRAND.name}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="col-span-12 md:col-span-8 md:pt-8"
          >
            <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-black leading-[1.05] tracking-tighter">
              The full broker stack,
              <br />
              <span className="text-gradient-brand">rebuilt for 2026.</span>
            </h2>
            <p className="text-gray-400 text-base leading-relaxed mt-6 max-w-2xl">
              {BRAND.name} engineers the technology layer that sits between your traders and the
              markets. We ship Forex CRM, liquidity bridges, copy trading, risk engines, and custom
              software — purpose-built to help brokers and prop firms scale without legacy drag.
            </p>
          </motion.div>
        </div>

        {/* Full-width image banner with overlaid stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative rounded-3xl overflow-hidden border border-white/10 mb-16"
        >
          <img
            src={ABOUT_IMAGE}
            alt="About Meta Broker Tool"
            className="w-full h-[360px] sm:h-[420px] object-cover transition-transform duration-[1.5s] hover:scale-[1.04]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-8 sm:p-12 grid grid-cols-2 sm:grid-cols-4 gap-8">
            {[
              { v: "12+", l: "Years Building" },
              { v: "40M+", l: "Daily Trades" },
              { v: "30+", l: "Countries" },
              { v: "0", l: "Downtime Incidents" },
            ].map((s, i) => (
              <motion.div
                key={s.l}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="text-left"
              >
                <div className="font-display text-3xl sm:text-5xl font-black text-white">
                  {s.v}
                </div>
                <div className="text-[10px] uppercase tracking-[0.25em] text-[#FF8A00] mt-1 font-bold">
                  {s.l}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Feature rows — alternating line list (NOT grid of cards) */}
        <div className="divide-y divide-white/10 border-y border-white/10">
          {ABOUT_FEATURES.map((f, i) => {
            const Icon = ICON_MAP[f.icon] || Zap;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06, duration: 0.5 }}
                data-testid={`about-feature-${i}`}
                className="group flex items-center gap-6 py-6 hover:pl-4 transition-all duration-500 cursor-default"
              >
                <div className="font-display text-xs text-gray-500 tabular-nums tracking-widest w-10 shrink-0">
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div
                  className={`w-12 h-12 shrink-0 rounded-xl flex items-center justify-center border ${
                    i % 2 === 0
                      ? "bg-[#2B7FFF]/10 border-[#2B7FFF]/40 text-[#2B7FFF]"
                      : "bg-[#FF8A00]/10 border-[#FF8A00]/40 text-[#FF8A00]"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 font-display text-base sm:text-lg text-gray-200 group-hover:text-white transition-colors">
                  {f.text}
                </div>
                <ArrowUpRight className="w-5 h-5 text-gray-600 group-hover:text-[#FF8A00] group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
              </motion.div>
            );
          })}
        </div>

        <div className="mt-12">
          <a
            href="/#contact"
            data-testid="about-cta"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] text-white px-7 py-3.5 rounded-full font-semibold btn-glow-blue"
          >
            Talk to our team
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
