import React from "react";
import { Mail, Phone, Twitter, Facebook, Instagram, Linkedin } from "lucide-react";
import { BRAND } from "../lib/constants";

export default function TopBar() {
  return (
    <div
      data-testid="top-contact-bar"
      className="hidden md:block bg-[#0A0A0C] border-b border-white/5 text-xs"
    >
      <div className="max-w-7xl mx-auto px-6 py-2 flex justify-between items-center text-gray-400">
        <div className="flex items-center gap-6">
          <a
            href={`mailto:${BRAND.email}`}
            data-testid="top-email-link"
            className="flex items-center gap-2 hover:text-[#2B7FFF] transition-colors"
          >
            <Mail className="w-3.5 h-3.5" />
            <span className="tracking-wide">{BRAND.email}</span>
          </a>
          <a
            href={`tel:${BRAND.phone.replace(/\s/g, "")}`}
            data-testid="top-phone-link"
            className="flex items-center gap-2 hover:text-[#FF8A00] transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            <span className="tracking-wide">{BRAND.phone}</span>
          </a>
        </div>
        <div className="flex items-center gap-5">
          {[
            { icon: Twitter, href: BRAND.socials.twitter, test: "top-twitter" },
            { icon: Facebook, href: BRAND.socials.facebook, test: "top-facebook" },
            { icon: Instagram, href: BRAND.socials.instagram, test: "top-instagram" },
            { icon: Linkedin, href: BRAND.socials.linkedin, test: "top-linkedin" },
          ].map(({ icon: Icon, href, test }) => (
            <a
              key={test}
              href={href}
              data-testid={test}
              aria-label={test}
              className="text-gray-500 hover:text-[#2B7FFF] transition-all hover:scale-110"
            >
              <Icon className="w-4 h-4" />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
