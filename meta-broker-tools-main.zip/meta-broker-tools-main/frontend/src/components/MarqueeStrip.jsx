import React from "react";
import Marquee from "react-fast-marquee";
import { Users, Award, Zap, Phone, Globe, ShieldCheck } from "lucide-react";

const ITEMS = [
  { icon: Users, text: "Senior Engineering Team", color: "#2B7FFF" },
  { icon: Award, text: "ISO-Aligned Delivery", color: "#FF8A00" },
  { icon: Zap, text: "Sub-Millisecond Execution", color: "#2B7FFF" },
  { icon: Phone, text: "24/7 Dedicated Support", color: "#FF8A00" },
  { icon: Globe, text: "Global Multi-Region Hosting", color: "#2B7FFF" },
  { icon: ShieldCheck, text: "Bank-Grade Security", color: "#FF8A00" },
];

export default function MarqueeStrip() {
  return (
    <section
      data-testid="marquee-strip"
      className="bg-[#0A0A0C] border-y border-white/10 py-5 overflow-hidden relative"
    >
      <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-black to-transparent z-10" />
      <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-black to-transparent z-10" />

      <Marquee gradient={false} speed={45} pauseOnHover>
        {ITEMS.concat(ITEMS).map((item, i) => {
          const Icon = item.icon;
          return (
            <div key={i} className="flex items-center gap-3 mx-10">
              <Icon className="w-5 h-5" style={{ color: item.color }} />
              <span className="font-display text-sm md:text-base text-white tracking-wide">
                {item.text}
              </span>
              <span className="ml-10 text-white/20">/</span>
            </div>
          );
        })}
      </Marquee>
    </section>
  );
}
