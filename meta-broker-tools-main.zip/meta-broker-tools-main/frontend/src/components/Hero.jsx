import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck, Zap, Users, Headphones, ArrowUpRight, TrendingUp,
  Activity, Globe2, Sparkles
} from "lucide-react";
import { HERO_IMAGES, BRAND } from "../lib/constants";

const TICKERS = [
  { pair: "EUR/USD", price: "1.0842", change: "+0.18%", up: true },
  { pair: "GBP/JPY", price: "184.31", change: "-0.42%", up: false },
  { pair: "XAU/USD", price: "2,041.5", change: "+1.24%", up: true },
  { pair: "BTC/USD", price: "67,420", change: "+2.10%", up: true },
];

export default function Hero() {
  const [bgIndex, setBgIndex] = useState(0);
  const [tickerIdx, setTickerIdx] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setBgIndex((i) => (i + 1) % HERO_IMAGES.length), 6500);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => setTickerIdx((i) => (i + 1) % TICKERS.length), 2200);
    return () => clearInterval(id);
  }, []);

  return (
    <section
      id="home"
      data-testid="hero-section"
      className="relative min-h-[92vh] flex items-center overflow-hidden noise-overlay"
    >
      {/* Background slider */}
      <AnimatePresence mode="wait">
        <motion.div
          key={bgIndex}
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.6, ease: "easeInOut" }}
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url('${HERO_IMAGES[bgIndex]}')` }}
        />
      </AnimatePresence>

      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/85 to-black" />
      <div className="absolute -left-40 top-20 w-[500px] h-[500px] bg-[#2B7FFF] rounded-full blur-[200px] opacity-25" />
      <div className="absolute -right-40 bottom-0 w-[500px] h-[500px] bg-[#FF8A00] rounded-full blur-[220px] opacity-20" />

      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)",
          backgroundSize: "80px 80px",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 w-full py-20">
        {/* Top announcement pill */}
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex justify-center mb-10"
        >
          <div className="inline-flex items-center gap-3 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full pl-2 pr-5 py-2 text-xs">
            <span className="bg-gradient-to-r from-[#2B7FFF] to-[#FF8A00] text-white px-3 py-1 rounded-full font-bold tracking-[0.18em]">
              NEW
            </span>
            <span className="text-gray-300 font-medium">
              Introducing {BRAND.name} v3 — now with AI-powered risk engine
            </span>
            <ArrowUpRight className="w-3.5 h-3.5 text-[#FF8A00]" />
          </div>
        </motion.div>

        {/* Big centered heading */}
        <div className="text-center max-w-5xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            data-testid="hero-heading"
            className="font-display text-[44px] sm:text-[64px] lg:text-[88px] font-black leading-[0.95] tracking-[-0.04em]"
          >
            Broker tech, <br className="hidden sm:block" />
            <span className="text-gradient-brand">reimagined</span> from
            <br className="hidden sm:block" />
            <span className="inline-flex items-baseline gap-4">
              the ground up.
              <Sparkles className="w-8 h-8 sm:w-12 sm:h-12 text-[#FF8A00] -translate-y-2" />
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.7 }}
            className="text-gray-300 mt-7 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed"
          >
            {BRAND.name} delivers a complete trading technology stack — CRM, liquidity,
            copy-trading, risk, and custom software — purpose-built for brokers and prop firms
            who refuse to compromise on speed.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-3 justify-center mt-10"
          >
            <a
              href="/#services"
              data-testid="hero-cta-services"
              className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#2B7FFF] to-[#1E90FF] text-white px-8 py-4 rounded-full font-semibold btn-glow-blue"
            >
              Explore Services
              <ArrowUpRight className="w-4 h-4" />
            </a>
            <a
              href="/#about"
              data-testid="hero-cta-demo"
              className="inline-flex items-center justify-center gap-2 bg-white/5 backdrop-blur-sm border border-white/15 hover:border-[#FF8A00] text-white px-8 py-4 rounded-full font-semibold transition-colors"
            >
              <Activity className="w-4 h-4 text-[#FF8A00]" />
              Watch Platform Demo
            </a>
          </motion.div>
        </div>

        {/* Bento grid below */}
        <div className="grid grid-cols-12 gap-4 sm:gap-5 mt-16 sm:mt-20">
          {/* Big live ticker card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.7 }}
            data-testid="hero-ticker-card"
            className="col-span-12 md:col-span-7 glass-panel rounded-2xl p-6 sm:p-7 relative overflow-hidden"
          >
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.22em] text-gray-400 font-bold">
                <span className="w-2 h-2 bg-[#2B7FFF] rounded-full animate-pulse" />
                Live Market Feed
              </div>
              <TrendingUp className="w-4 h-4 text-[#FF8A00]" />
            </div>

            <div className="relative  overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.div
                  key={tickerIdx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.45 }}
                  className="flex items-baseline justify-between flex-wrap gap-4"
                >
                  <div>
                    <div className="text-xs uppercase tracking-[0.2em] text-gray-400">
                      {TICKERS[tickerIdx].pair}
                    </div>
                    <div className="font-display text-5xl sm:text-6xl font-black text-gradient-brand mt-2 ticker-glow">
                      {TICKERS[tickerIdx].price}
                    </div>
                    <div
                      className={`text-sm font-semibold mt-2 ${
                        TICKERS[tickerIdx].up ? "text-[#2B7FFF]" : "text-[#FF8A00]"
                      }`}
                    >
                      {TICKERS[tickerIdx].change} {TICKERS[tickerIdx].up ? "▲" : "▼"}
                    </div>
                  </div>

                  {/* Mini candlestick animation */}
                  <div className="flex items-end gap-1.5 h-20">
                    {[...Array(14)].map((_, i) => (
                      <div
                        key={i}
                        className="w-2 rounded-sm candle-anim"
                        style={{
                          height: `${30 + ((i * 17) % 60)}%`,
                          background: i % 2 === 0 ? "#2B7FFF" : "#FF8A00",
                          animationDelay: `${i * 0.15}s`,
                        }}
                      />
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Dots */}
            <div className="flex gap-2 mt-5">
              {TICKERS.map((_, i) => (
                <div
                  key={i}
                  className={`h-1 rounded-full transition-all ${
                    i === tickerIdx ? "w-8 bg-[#2B7FFF]" : "w-2 bg-white/20"
                  }`}
                />
              ))}
            </div>
          </motion.div>

          {/* Stats pill card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.7 }}
            className="col-span-6 md:col-span-3 glass-panel rounded-2xl p-6 flex flex-col justify-between"
            data-testid="hero-stat-brokers"
          >
            <Globe2 className="w-6 h-6 text-[#2B7FFF]" />
            <div>
              <div className="font-display text-5xl font-black text-gradient-brand">500+</div>
              <div className="text-xs uppercase tracking-[0.22em] text-gray-400 mt-2 font-bold">
                Broker Deployments
              </div>
            </div>
          </motion.div>

          {/* Uptime card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.7 }}
            className="col-span-6 md:col-span-2 glass-panel rounded-2xl p-6 flex flex-col justify-between"
            data-testid="hero-stat-uptime"
          >
            <ShieldCheck className="w-6 h-6 text-[#FF8A00]" />
            <div>
              <div className="font-display text-4xl font-black text-gradient-brand">99.99%</div>
              <div className="text-xs uppercase tracking-[0.22em] text-gray-400 mt-2 font-bold">
                Uptime SLA
              </div>
            </div>
          </motion.div>

          {/* Feature row */}
          {[
            { Icon: ShieldCheck, title: "Bank-Grade Security", sub: "AES-256 • SOC2" },
            { Icon: Zap, title: "Sub-ms Latency", sub: "Co-located matching" },
            { Icon: Users, title: "Senior Team", sub: "Markets + engineering" },
            { Icon: Headphones, title: "24 / 7 Desk", sub: "Follow-the-sun" },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 + i * 0.08, duration: 0.55 }}
              data-testid={`hero-feature-${i}`}
              className="col-span-6 md:col-span-3 group glass-panel rounded-2xl p-5 flex items-center gap-4 hover:border-[#2B7FFF]/40 transition-all"
            >
              <div
                className={`w-11 h-11 shrink-0 rounded-xl flex items-center justify-center border ${
                  i % 2 === 0
                    ? "bg-[#2B7FFF]/10 border-[#2B7FFF]/40 text-[#2B7FFF]"
                    : "bg-[#FF8A00]/10 border-[#FF8A00]/40 text-[#FF8A00]"
                }`}
              >
                <f.Icon className="w-5 h-5" />
              </div>
              <div>
                <div className="font-display text-sm font-semibold text-white">{f.title}</div>
                <div className="text-xs text-gray-400 mt-0.5">{f.sub}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
