import React from "react";
import { motion } from "framer-motion";
import { Headphones, ArrowRight, CheckCircle2 } from "lucide-react";
import { CRM_IMAGE } from "../lib/constants";

const POINTS = [
  "Trader's room with KYC, deposits, and wallet flows",
  "Visual IB tree with automatic commission calculations",
  "Real-time exposure, risk, and P&L dashboards",
];

export default function CRMHighlight() {
  return (
    <section
      id="fx"
      data-testid="crm-highlight"
      className="relative bg-black py-20 sm:py-28"
    >
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="relative rounded-3xl overflow-hidden border border-[#2B7FFF]/30 bg-gradient-to-br from-[#050510] via-black to-[#0A0500] p-8 sm:p-12"
        >
          <div className="absolute -top-32 -right-32 w-96 h-96 bg-[#2B7FFF] rounded-full blur-[180px] opacity-20" />
          <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-[#FF8A00] rounded-full blur-[180px] opacity-15" />

          <div className="grid md:grid-cols-2 gap-12 items-center relative">
            {/* Images */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src={CRM_IMAGE}
                  alt="CRM Dashboard"
                  className="w-full h-auto object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
              {/* Floating ticker card */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 }}
                className="absolute -bottom-6 -right-6 glass-panel rounded-xl p-4 w-48 hidden sm:block"
              >
                <div className="text-[10px] uppercase tracking-[0.2em] text-gray-400">EUR / USD</div>
                <div className="font-display text-2xl font-bold text-gradient-brand mt-1">1.0842</div>
                <div className="text-xs text-[#2B7FFF] mt-1">+0.18% ▲</div>
              </motion.div>
            </motion.div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="inline-flex items-center gap-2 bg-[#FF8A00]/15 border border-[#FF8A00]/30 text-[#FF8A00] px-4 py-1.5 rounded-full text-[11px] font-bold tracking-[0.22em] uppercase mb-5">
                Flagship Product
              </span>

              <h3 className="font-display text-3xl sm:text-4xl font-black leading-tight tracking-tight">
                <span className="text-gradient-brand">Complete CRM</span>
                <br /> engineered for brokers
              </h3>

              <p className="text-gray-400 mt-5 leading-relaxed">
                Our CRM unifies client onboarding, wallet management, IB networks, and risk into a
                single, real-time workspace. Launch in weeks, not quarters — and ship features your
                competitors still have on a roadmap.
              </p>

              <div className="space-y-3 mt-7">
                {POINTS.map((p, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 * i }}
                    className="flex items-start gap-3"
                    data-testid={`crm-point-${i}`}
                  >
                    <CheckCircle2 className="w-5 h-5 text-[#2B7FFF] shrink-0 mt-0.5" />
                    <span className="text-gray-300 text-sm">{p}</span>
                  </motion.div>
                ))}
              </div>

              <a
                href="/#contact"
                data-testid="crm-cta"
                className="inline-flex items-center gap-2 mt-8 bg-gradient-to-r from-[#FF8A00] to-[#2B7FFF] text-white px-7 py-3 rounded-full font-semibold btn-glow-orange"
              >
                <Headphones className="w-4 h-4" />
                Learn About Our CRM
                <ArrowRight className="w-4 h-4" />
              </a>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
