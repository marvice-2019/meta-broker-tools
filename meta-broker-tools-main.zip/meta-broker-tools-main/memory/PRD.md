# Meta Broker Tool — PRD

## Problem Statement
User provided a reference Infyst forex-broker HTML template and asked to rebuild it as "Meta Broker Tool" using the uploaded blue/orange-on-black logo. After first pass, user requested distinctive layouts (not a copy), removal of the "Made with Emergent" badge, and larger logos in navbar + footer.

## User Choices
- Brand: Meta Broker Tool / "Next-Gen Forex Broker Solutions"
- Content: mix of forex broker tools + generic tech services
- Contact: placeholder info (editable)
- Frontend only (React + Tailwind), no backend
- Remove video/shopping section from reference
- Distinctive layouts (centered hero + bento grid + numbered service list)

## Architecture
- React 19 + Tailwind + framer-motion + react-fast-marquee + lucide-react
- Shadcn UI available at /app/frontend/src/components/ui/
- Fonts: Unbounded (display), Manrope (body)
- Palette: #2B7FFF (blue), #FF8A00 (orange), #000000 bg

## Implemented
- TopBar, Header (with Fx mega dropdown + mobile drawer)
- Hero (centered typographic + live ticker bento + stat cards)
- About (numbered "01" hero + full-width banner with inline stats + numbered feature rows)
- Marquee strip
- CRM Highlight card with floating price badge
- Services (numbered row layout with hover gradients)
- Why Choose Us FAQ accordion (custom, not shadcn)
- KYC/AML Compliance card
- CTA panel with glass effect
- Footer (4-column, newsletter, socials)
- Logo bumped to h-20 in nav + h-20 in footer
- Emergent badge removed via public/index.html + CSS fallback

## P1 / Next
- Hook newsletter form to real backend or Resend
- Add route for individual Fx-Technology pages
- Add case studies / testimonials section
- Add contact form page
